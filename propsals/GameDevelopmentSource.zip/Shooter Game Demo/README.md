Here's a step-by-step guide to building a game from scratch in JavaScript.

[Play it!](http://mimswright.com/games/huge-gamedemo/)

Be sure to *View Source*!
